// Terry Hodge 8-20-2021
// CE05

// these alerts let the user know what we will be prompting for today
alert("Welcome to the Double Discount checker!");
alert("I will ask you for the prices of 2 items and then calculate your total with any discounts that apply.");

// this allows the user to give us the  first cost in a decimal format
let item1Cost = parseFloat(prompt("What is the cost of your first item?"));
// here we promt for the second item cost
let item2Cost = parseFloat(prompt("What is the cost of your second item?"));
// I needed the total for the first two items for calculations further in the Javascript
let total = item1Cost+item2Cost
// next I used the total as a base and added in the discount making sure to have the right decimal point showing in the HTML
let total10 = total-(total*.10);
// here si did the same as about but for 5%
let total5 = total-(total*.05);

// now I added my first if statement to show the total with a 10% discountand green background
if(total>=100)
{
    document.querySelector("#finalCost").innerHTML = "Your total purchase is $"+total10.toFixed(2)+" which includes your 10% discount.";
    document.querySelector("#finalCost").style.background = "green"
}
// here i added the else if statement for the 5% discount and green background
else if(total>=50 && total<100)
{
    document.querySelector("#finalCost").innerHTML = "Your total purchase is $"+total5.toFixed(2)+" which includes your 5% discount.";
    document.querySelector("#finalCost").style.background = "green"

}
// here I needed to show the price with no discount and a yellow background
else if(total>=0 && total<49.9)
{
    document.querySelector("#finalCost").innerHTML = "Your total purchase is $"+total.toFixed(2)+".";
    document.querySelector("#finalCost").style.background = "yellow"
    document.querySelector("#finalCost").style.color = "black"
}
// this statement is made to catch all the unexpected respones from the user and alert them to refresh the page
else 
{
    alert("Something went wrong, please refresh the page")
}

// this alert lets the user know we are mving on to a new topic
alert("Let's find out if you can cross the desert with the gas you have left or if you should stop for gas.");
// here we ask for the max gallons from the user
let maxGallons = parseInt(prompt("What is the maximum number of gallons your car's gas tank can hold?"));
// next we need the percent of gas left
let percentLeft = parseInt(prompt("What percent of those 20 gallons are left?"));
// lastly we ask the user for the MPG of the car
let milesPerGallon = parseInt(prompt("How many miles per gallon can your car go?"));
// next up i calculated the total drivable miles based on prompts
let milesDrive = milesPerGallon*(maxGallons*(percentLeft/100));

// here i used my first if statement to fill in the text and images and make the buttoms clickable with the information needed
if(milesDrive>=200)
{
    document.querySelector("#milesDriven").innerHTML = "Yes, you can drive "+milesDrive+" and you can make it without stopping for gas!";
    document.querySelector("#showText").addEventListener("click",function(e)
    { 
        
        document.querySelector("#milesDriven").style.visibility = "visible";
        });

    document.querySelector("#showGraph").addEventListener("click",function(e)
   { 
    document.querySelector("#enoughGas").src = "IMG/enoughGas.jpg";
    document.querySelector("#enoughGas").style.visibility = "visible";
    });
}
// in this else if i make the buttons clickable with a different image and message based on user input
else if(milesDrive<=199.99)
{
    document.querySelector("#milesDriven").innerHTML = "You can only drive "+milesDrive+" miles more, better get gas now while you can!";
    document.querySelector("#showText").addEventListener("click",function(e)
    { 
        
        document.querySelector("#milesDriven").style.visibility = "visible";
        });

    document.querySelector("#showGraph").addEventListener("click",function(e)
   { 
    document.querySelector("#notEnoughGas").src = "IMG/notEnoughGas.jpg";
    document.querySelector("#notEnoughGas").style.visibility = "visible";
    });
}
//this alert is made to tell the user to refresh the page if they imput unexpected information
else{
    alert("Ooops something went wrong please refresh the page.")
}